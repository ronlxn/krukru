import pygame
from sys import exit
import os

#variables
window_width = 800
window_height = 600

player_x = window_width/2 #position x-axis
player_y = window_height/2 #position y-axis


player_velocity_y = -10
GRAVITY = 0.5
# FLOOR_Y = 



#START?
ground = pygame.Rect(0, 550, 800, 50) #left, top, width, height

#IMAGES
player_static_right = pygame.image.load(os.path.join("images", "static_right.png"))
player_static_left = pygame.image.load(os.path.join("images", "static_left.png"))



#WINDOW
pygame.init()
window = pygame.display.set_mode((window_width, window_height)) #, pygame.FULLSCREEN
pygame.display.set_caption("WHAT GAME") #game name
pygame.display.set_icon(player_static_right) #game icon
clock = pygame.time.Clock() #declare for time(timeframe)




class Player():
    def __init__(self, player_x, player_y):
        self.player_x = player_x
        self.player_y = player_y
        self.image = player_static_right
        self.velocity_y = 0
        
        
        
#left(x), top(y)
player = Player(50, 50)


def move():
    player.velocity_y += GRAVITY
    player.player_y += player.velocity_y
    #window_height/2 += -10
    
    if player.player_y >= 500:  # adjust based on sprite height
        player.player_y = 500
        player.velocity_y = 0

def draw(): #color of background
    window.fill("#0088aa")
    pygame.draw.rect(window, "#FFFFFF", ground)
    window.blit(player_static_right,(player_x, player_y)) #blit is for displaying the image

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: #for x button
            pygame.quit()
            exit()
            
                
    keys = pygame.key.get_pressed() #smooth travel
    if keys[pygame.K_SPACE]:
        player.velocity_y = player_velocity_y
    if keys[pygame.K_LEFT]:
        player_x -= 5
    if keys[pygame.K_RIGHT]:
        player_x += 5
    
    move()
    draw()
    pygame.display.update()
    clock.tick(60) #60 frames per second
    