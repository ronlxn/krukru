import pygame
from pygame.locals import *
import os
import random
import math

pygame.init()

#screen size
screen_width = 800
screen_height = 600

#time frame
clock = pygame.time.Clock()

screen = pygame.display.set_mode((screen_width, screen_height)) #, pygame.FULLSCREEN
pygame.display.set_caption("WHAT")#----> title




#FOR GRID
tile_size = 32


class DeathParticle():
    pass
    


class Player():
    def __init__(self, PLAYER_X, PLAYER_Y): #POSITION X, Y
        self.start_x = PLAYER_X
        self.start_y = PLAYER_Y
        #IMAGES
        self.player_static_r = pygame.image.load(os.path.join("image_s", "static.png"))
        self.player_static_r = pygame.transform.scale(self.player_static_r, (32, 36))

        
        self.player_moving_r = [#list
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_1.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_2.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_3.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_4.png")), (32, 36)),
        ]
        
        #FLIP THR RIGHT TO LEFT HAHAHAHAHAHAHAHAHAHAHAHAHAHAHA JK
        self.player_static_l = pygame.transform.flip(self.player_static_r, True, False)
        self.player_moving_l = [
            pygame.transform.flip(img, True, False) for img in self.player_moving_r
        ]
        
        #IMAGE CONTAINER
        self.image = self.player_moving_r[1] #1 for moving
        
        #FOR POSITIONING
        self.rect = pygame.Rect(0, 0, 17, 36)
        self.rect.x = PLAYER_X
        self.rect.y = PLAYER_Y
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        
        #FOR THE PHYSICS AY/SPEED FOR X AND Y
        self.VELOCITY_Y = 0
        self.VELOCITY_X = 0

        
        self.direction = "right"
        self.state = "static"
        
        self.frame_index = 0 #which frame is currently showing
        self.animation_speed = 0.20 #how fast the sprite frames for every loop
        
        
    
    def movement(self):
        keys = pygame.key.get_pressed() #smooth movement (continuous)
        self.moving = False #reset every frame
        self.VELOCITY_X = 0 #reset so player doesnt accelerate forever
        
        #for keys
        if keys[pygame.K_LEFT]:
            self.VELOCITY_X -= 5 #-5
            self.direction = "left"
            self.moving = True
            
        if keys[pygame.K_RIGHT]:
            self.VELOCITY_X += 5 #+5
            self.direction = "right"
            self.moving = True
        
        #move x first then check collisions
        self.rect.x += self.VELOCITY_X #150 + (-+5) = ?
        self.check_collision_x()
        
        #GRAVITY
        self.VELOCITY_Y += 0.8 #velocity gets down(since positive)----> what pulls the velocity down
        if self.VELOCITY_Y > 10: #for jump
            self.VELOCITY_Y = 10 #limit fall speed
        self.rect.y += self.VELOCITY_Y
        self.check_collision_y()
        
        
        if self.VELOCITY_Y != 0:
            self.state = "jump"
        elif self.moving:
            self.state = "walk"
        else:
            self.state = "static"
        
        #frame
        if self.state != "walk":
            self.frame_index = 0
            
            
        # #CONDITION FOR MOVEMENT(WALKING)
        if self.state == "walk":
            self.frame_index += self.animation_speed #0 + 0.15 if moving
            
            #if frame sprite is >= number in list(4), it resets to 0----> to reset the frames
            if self.frame_index >= len(self.player_moving_r): #len() for getting the list from the player_moving_r sa taas #if 0.15 >= 2 -> so false
                self.frame_index = 0 #goes back
            
            if self.direction == "right":
                self.image = self.player_moving_r[int(self.frame_index)]
            else:
                self.image = self.player_moving_l[int(self.frame_index)]
                
        elif self.state == "jump":
            if self.direction == "right":
                self.image = self.player_moving_r[1]
            else:
                self.image = self.player_moving_l[1]

            
        else:
            self.frame_index = 0
            
            if self.direction == "right":
                self.image = self.player_static_r
            else:
                self.image = self.player_static_l
                
          
        
    def check_collision_x(self):
        for tile in world.tile_list:
            if isinstance(tile, Falling_Block) and tile.falling:
                continue
            if self.rect.colliderect(tile.rect):
                if self.VELOCITY_X > 0:
                     self.rect.right = tile.rect.left
                elif self.VELOCITY_X < 0:
                    self.rect.left = tile.rect.right
        
    def check_collision_y(self):
        for tile in world.tile_list:
            if isinstance(tile, Falling_Block) and tile.falling:
                continue
            if tile.rect.colliderect(self.rect):
                if self.VELOCITY_Y > 0: #falling down
                    self.rect.bottom = tile.rect.top
                    self.VELOCITY_Y = 0
                elif self.VELOCITY_Y < 0: #jumping up
                    self.rect.top = tile.rect.bottom
                    self.VELOCITY_Y = 0

#---------->
    
    def draw(self, surface):
        image_x = self.rect.x - (self.image.get_width() - self.rect.width) // 2
        image_y = self.rect.y - (self.image.get_height() - self.rect.height) // 2
        surface.blit(self.image, (image_x, image_y))
    
    def reset(self):
        self.rect.x = self.start_x
        self.rect.y = self.start_y
        self.VELOCITY_X = 0
        self.VELOCITY_Y = 0
        self.state = "static"

class World():
    def __init__(self, data):
        self.tile_list = [] #---->sotres all created tiles in here
        
        #SPRITE GROUPS
        self.falling_blocks = pygame.sprite.Group()
        self.spikes = pygame.sprite.Group()
        # self.enemies = pygame.sprite.Group()

        tile_surface = pygame.Surface((tile_size, tile_size))
        tile_surface.fill("#003a49")
        
        tile_surfs =  pygame.Surface((tile_size, tile_size))
        tile_surfs.fill("#003a49")
        
        spike_img = pygame.transform.scale(pygame.image.load(os.path.join("image_s", "spike_static.png")), (32, 7))
        
        # door_img = pygame.transform.scale(pygame.image.load(os.path.join("image_s", "door.png")), (36, 36))

        for row_index, row in enumerate(data): #Loops through every cell in your 2D grid.
            for column_index, tile_type in enumerate(row): #Converts the grid position into pixel coordinates — e.g. column 3 = 3×50 = 150px from the left.
                    rect_x = column_index * tile_size
                    rect_y = row_index * tile_size
                    
                    if tile_type == 1: #Tile
                        self.tile_list.append(Tile(rect_x, rect_y, tile_surface))
                    elif tile_type == 2: #Fallingblock
                        self.falling_blocks.add(
                            Falling_Block(rect_x, rect_y, tile_surfs, 50)
                        )
                    elif tile_type == 3: #Spike
                        self.spikes.add(
                            Spike(rect_x, rect_y, spike_img)
                        )
                    # elif tile_type == 4: #Door
                    #     self.tile_list.append()
                        

    
    def draw(self): #Loops through every tile and draws it onto the screen.
        for tile in self.tile_list:
            tile.draw(screen)
        
        self.falling_blocks.draw(screen)
        self.spikes.draw(screen)
        # self.enemies.draw(screen)

# class Enemy(pygame.sprite.Sprite):
#     def __init__(self, x, y):
#         pygame.sprite.Sprite.__init__(self)
#         self.image = pygame.transform.scale(pygame.image.load(os.path.join("image_s", "door.png")), (36, 36))
#         self.rect = self.image.get_rect()
#         self.rect.x = x
#         self.rect.y = y
        
    def draw():
        pass
        
        
        
        

class Tile():
    def __init__(self, rect_x, rect_y, image):
        self.image = image
        self.rect = image.get_rect()
        self.rect.x = rect_x #builtin attribute (.x)
        self.rect.y = rect_y #same here
        
    def draw(self, screen): #puts tile on the screen
        screen.blit(self.image, self.rect)
        

class Falling_Block(pygame.sprite.Sprite):
    def __init__(self, rect_x, rect_y, image, fall_speed):
        super().__init__()
        self.fall_speed = fall_speed
        self.falling = False
        self.trigger_range = 50 #how many pixels away the trigger
        
    def trigger(self, player):
        player_center_x = player.rect.centerx
        block_center_x = self.rect.centerx
        
        distance = abs(player_center_x - block_center_x) #horizontal d (absolute value so it can wrkk left or right of the block)
        
        if distance <= self.trigger_range:
            self.falling = True

    # def trigger(self, player):
    #     dx = abs(player.rect.centerx - self.rect.centerx)
    #     dy = abs(player.rect.centery - self.rect.centery)

    #     if dx <= self.trigger_range and dy <= 100:  # within range horizontally AND roughly same height
    #         self.falling = True

    def update_afttrigger(self):
        if self.falling:
            self.rect.y += self.fall_speed
            if self.rect.y > screen_height + 100:
                world.tile_list.remove(self)
            
    #Every frame, if the block is falling, it moves down by fall_speed pixels. Note: with a fall speed of 50 it'll jump very fast each frame — you may want to lower this.


class Spike(pygame.sprite.Sprite):
    def __init__(self, rect_x, rect_y, image):
        super().__init__()
        self.image = image
        
        self.rect = pygame.Rect(rect_x, rect_y + (32 - 7), 32, 7)

    def check_player_hit(self, player):
        if self.rect.colliderect(player.rect):
            player.reset()
            


world_data = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1]
]

# 12 x 25 = 





def draw_grid():
    for line in range(0,100):
        pygame.draw.line(screen, (255, 255, 255), (0, line* tile_size), (screen_width, line * tile_size))
        pygame.draw.line(screen, (255, 255, 255), (line* tile_size, 0), (line * tile_size, screen_width))



player = Player(150, 200) # x, y
world = World(world_data)







#MAIN LOOP
run = True
while run:
    
    screen.fill("#0088aa")
    
    player.movement()
    
    for tile in world.tile_list:
        # if isinstance(tile, Falling_Block):
        #     if not tile.falling:
        #         tile.trigger(player)
        #         tile.update_afttrigger()
        
            
        if player.rect.colliderect(tile.rect):
            # X collision
            if player.VELOCITY_X > 0:
                player.rect.right = tile.rect.left
            elif player.VELOCITY_X < 0:
                player.rect.left = tile.rect.right

            # Y collision
            if player.VELOCITY_Y > 0:
                player.rect.bottom = tile.rect.top
                player.VELOCITY_Y = 0
            elif player.VELOCITY_Y < 0:
                player.rect.top = tile.rect.bottom
                player.VELOCITY_Y = 0
    
    # -------------------------
    # FALLING BLOCKS (SPRITES)
    # -------------------------
    for block in world.falling_blocks:
        block.trigger(player)
        block.update_afttrigger()

    # -------------------------
    # SPIKES (SPRITES)
    # -------------------------
    for spike in world.spikes:
        if spike.rect.colliderect(player.rect):
            player.reset()
            
    # -------------------------
    # DRAW EVERYTHING
    # -------------------------
    world.draw()
    player.draw(screen)
    
    
    # draw_grid()

    
    # print(world.tile_list)
    
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and player.VELOCITY_Y == 0:
                player.VELOCITY_Y = -14
                  
        # if keys[pygame.K_SPACE] and self.VELOCITY_Y == 0:
        #     self.VELOCITY_Y = -12 #velocity becomes -12(goes up)
        

    pygame.display.update() #----> to show the content
    clock.tick(60) #----> 60 frames per second
    
    #KEYS
    
        
    
            
pygame.quit()
